import { useState } from "react";

function InvestForm({ onSubmitForm }) {
  const [userInput, setUserInput] = useState({
    currentSavings: 0,
    yearlySavings: 0,
    expectedInterest: 0,
    duration: 0,
  });

  const userInputHandler = (event) => {
    const { name, value } = event.target;
    setUserInput({
      ...userInput,
      [name]: value,
    });
    console.log(userInput);
  };

  const investFormSubmitHandler = (event) => {
    event.preventDefault();
    console.log(userInput);
    onSubmitForm(userInput);
  };

  return (
    <form className="form" onSubmit={investFormSubmitHandler}>
      <div className="input-group">
        <p>
          <label htmlFor="current-savings">Current Savings ($)</label>
          <input
            type="number"
            id="current-savings"
            name="currentSavings"
            onChange={userInputHandler}
          />
        </p>
        <p>
          <label htmlFor="yearly-contribution">Yearly Savings ($)</label>
          <input
            type="number"
            id="yearly-contribution"
            name="yearlySavings"
            onChange={userInputHandler}
          />
        </p>
      </div>
      <div className="input-group">
        <p>
          <label htmlFor="expected-return">
            Expected Interest (%, per year)
          </label>
          <input
            type="number"
            id="expected-return"
            name="expectedInterest"
            onChange={userInputHandler}
          />
        </p>
        <p>
          <label htmlFor="duration">Investment Duration (years)</label>
          <input
            type="number"
            id="duration"
            name="duration"
            onChange={userInputHandler}
          />
        </p>
      </div>
      <p className="actions">
        <button type="reset" className="buttonAlt">
          Reset
        </button>
        <button type="submit" className="button">
          Calculate
        </button>
      </p>
    </form>
  );
}

export default InvestForm;
